-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 13, 2023 at 05:09 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `venda_plus`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `user` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(100) NOT NULL,
  `password_hash` varchar(250) NOT NULL,
  `created_at` date NOT NULL DEFAULT current_timestamp(),
  `user_verification_code` varchar(250) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `user`, `email`, `password`, `password_hash`, `created_at`, `user_verification_code`, `status`) VALUES
(1, 'nelioquibe', 'nelioquibe.nq@gmail.com', '123456', '', '2023-11-12', '', 'Logout'),
(2, 'nelioquibe', 'nelioquibe.nq@gmail.com', '123456', '', '2023-11-12', '', 'Logout'),
(3, 'nelioquibe', 'nelioquibe.nq@gmail.com', '123456', '', '2023-11-12', '', 'Logout'),
(4, 'nelioquibe', 'nelioquibe.nq@gmail.com', '123456', '', '2023-11-12', '', 'Logout'),
(5, 'jaimedeleite', 'jaimedeleite@gmail.com', '123456', '', '2023-11-12', '', 'Logout'),
(6, 'jaimedeleite', 'jaimedeleite@gmail.com', '123456', '', '2023-11-12', '', 'Logout'),
(7, 'salmaquibe', 'salmaquibe.sq@gmail.com', '123456', '', '2023-11-12', '', 'Logout'),
(8, 'salmaquibe', 'salmaquibe.sq@gmail.com', '123456', '', '2023-11-12', '', 'Logout'),
(9, 'dfgddf', 'dfdfdf', 'dfdfdfd', '', '2023-11-12', '', 'Logout'),
(10, 'dfgddf', 'dfdfdf', 'dfdfdfd', '', '2023-11-12', '', 'Logout'),
(11, 'dfgddf', 'dfdfdf', 'dfdfdfd', '', '2023-11-12', '', 'Logout'),
(12, 'nelioquibe', 'nelioquibe.nq@gmail.com', '123456', '', '2023-11-12', '', 'Logout'),
(13, '', '', '', '', '2023-11-12', '', 'Logout'),
(14, '', '', '', '', '2023-11-12', '', 'Logout'),
(15, 'sdsd', 'wew', 'sds', '', '2023-11-12', '', 'Logout'),
(16, 'jjjjjj', 'jjjjjjjj', 'jjjjjjjjjj', '', '2023-11-12', '', 'Logout'),
(17, 'jjjjjj', 'jjjjjjjj', 'jjjjjjjjjj', '', '2023-11-12', '', 'Logout'),
(18, 'jjjjjj', 'jjjjjjjj', 'jjjjjjjjjj', '', '2023-11-12', '', 'Logout'),
(19, 'jaimedeleite', 'salmaquibe.sq@gmail.com', '123456', '', '2023-11-13', '', 'Logout'),
(20, 'nelioquibe', 'jaimedeleite@gmail.com', '123456', '', '2023-11-13', '', 'Logout'),
(21, 'cardoso', 'cardoso@gmail.com', '123456', '', '2023-11-13', '', 'Logout'),
(22, 'nelioquibe', 'jaimedeleite@gmail.com', 'xdfg', '', '2023-11-13', '', 'Logout'),
(23, 'dfgh', 'drt', 'dert', '', '2023-11-13', '', 'Logout');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
